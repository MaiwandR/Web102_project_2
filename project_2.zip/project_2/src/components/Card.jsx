import React from 'react';
import {useState} from 'react';


const Card = (props) => {
    const [isFlipped, setIsFlipped] = useState(false);

   
return(

    

    <>
    
    <div className="card" onClick={() => setIsFlipped(!isFlipped)}>

      {isFlipped ? <h2 className="answer">{props.answer}</h2> : <h2 className="question">{props.question}</h2>}

    </div>
    
    </>

)

}

export default Card;