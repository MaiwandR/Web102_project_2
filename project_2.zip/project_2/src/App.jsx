import './App.css';
import Counter from './components/Counter';
import Card from './components/card';
import {useState} from 'react';


const App = () => {

const flashcards = [
    {question: "What is your name?", answer: "ستاسو نوم چی ده؟"},
    {question: "How are you?", answer: "تاسو څنګه یئ؟"},
    {question:"Where are you from?", answer: "تاسو د کوم ځای یاست؟"},
    {question:"What is your job?", answer: "ستاسو کار څه دی؟"},
    {question:"I am happy to see you.", answer: "زه ستا په لیدو خوشحاله شوم"},
    {question:"I am from Afghanistan.", answer: "زه د افغانستان یم"},
];

const [currentCard, setCurrentCard] = useState(0);


const nextCard = () => {
    setCurrentCard((curr) => (curr + 1) % flashcards.length);
};

const prevCard = () => {
  setCurrentCard((curr) => curr=== 0 ?flashcards.length -1 : curr - 1);
};


  return (
    <div className="App">
      
      <h2 className="title">Prove Your Pashto Skills!</h2>

      
      <h3 className="subtitle">Click to Reveal!</h3>
      <Counter indx = {currentCard}></Counter>
      

      <div className="main">
        <button className="prev" onClick={prevCard}>&#x3C;</button>
        <Card question= {flashcards[currentCard].question} answer={flashcards[currentCard].answer}></Card>
        <button className="next" onClick={nextCard}>&#62;</button>

      </div>


    </div>
  )
}

export default App
